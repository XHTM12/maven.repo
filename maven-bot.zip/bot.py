import os, json, time, hmac, hashlib, sqlite3
from urllib.parse import parse_qsl
from aiohttp import web
from telegram import Update, InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

BOT_TOKEN = os.environ["BOT_TOKEN"]          # set in your host's env vars, never in code
BOT_USERNAME = os.getenv("BOT_USERNAME", "maven_shop_bot")
ADMIN_ID = int(os.getenv("ADMIN_ID", "8212988779"))
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://YOUR-APP.vercel.app")
PORT = int(os.getenv("PORT", "8080"))

db = sqlite3.connect("maven_store.db", check_same_thread=False)
db.executescript("""
CREATE TABLE IF NOT EXISTS users (user_id TEXT PRIMARY KEY, username TEXT, referred_by TEXT, referrals_count INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, uid TEXT, product TEXT, price TEXT, status TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY AUTOINCREMENT, uid TEXT, sender TEXT, text TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS relay (admin_msg_id INTEGER PRIMARY KEY, uid TEXT);
""")
db.commit()
q = lambda sql, a=(): db.execute(sql, a).fetchall()
last_seen = {}  # uid -> last chat poll time, used to decide whether to DM the user

def add_chat(uid, sender, text):
    db.execute("INSERT INTO chat (uid, sender, text, ts) VALUES (?,?,?,?)", (uid, sender, text, int(time.time())))
    db.commit()

def open_chat_kb(label="💬 Open Live Chat"):
    return Kb([[Btn(label, web_app=WebAppInfo(url=f"{WEBAPP_URL}?tab=chat"))]])

# ---------- bot commands ----------
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user, uid = update.effective_user, str(update.effective_user.id)
    if not q("SELECT 1 FROM users WHERE user_id=?", (uid,)):
        ref = None
        if ctx.args and ctx.args[0].startswith("ref_"):
            r = ctx.args[0][4:].strip()
            if r and r != uid:
                ref = r
                db.execute("INSERT OR IGNORE INTO users (user_id, referrals_count) VALUES (?,0)", (r,))
                db.execute("UPDATE users SET referrals_count = referrals_count + 1 WHERE user_id=?", (r,))
                try:
                    await ctx.bot.send_message(int(r), f"🎉 New referral: {user.first_name} joined with your link!\n✨ +10 Credits (20 ETB discount)")
                except Exception:
                    pass
        db.execute("INSERT INTO users (user_id, username, referred_by) VALUES (?,?,?)", (uid, user.username, ref))
        db.commit()
    n = q("SELECT referrals_count FROM users WHERE user_id=?", (uid,))[0][0]
    rows = [[Btn("🛍 Open Maven Store", web_app=WebAppInfo(url=f"{WEBAPP_URL}?refs={n}"))],
            [Btn("📢 Join Official Channel", url="https://t.me/maven_offical_seller")],
            [Btn("🎁 My Referral Stats", callback_data="ref_stats")]]
    await update.message.reply_text(
        f"💜 Welcome to Maven Store, {user.first_name}!\n\n⚡ AI, Movie, Gift Card & Software subscriptions\n"
        f"💱 Fixed rate: 200 Birr = 1 USDT\n\n👥 Invited: {n} | ✨ Credits: {n*10} ({n*20} ETB off)\n"
        f"🔗 Your link:\nhttps://t.me/{BOT_USERNAME}?start=ref_{uid}", reply_markup=Kb(rows))

async def ref_stats(update: Update, ctx):
    qy = update.callback_query; await qy.answer()
    uid = str(qy.from_user.id)
    r = q("SELECT referrals_count FROM users WHERE user_id=?", (uid,)); n = r[0][0] if r else 0
    await qy.message.reply_text(f"🎁 Referrals: {n}/15\n✨ Credits: {n*10}\n💸 Discount: {n*20} Birr\n\n"
        f"🏆 Invite 15 friends for a FREE 18-month Gemini Pro Family plan!\n\nhttps://t.me/{BOT_USERNAME}?start=ref_{uid}")

# ---------- approve / decline ----------
async def order_decision(update: Update, ctx):
    qy = update.callback_query; await qy.answer()
    parts = qy.data.split("_"); action, oid, uid = parts[0], parts[-1], "_".join(parts[1:-1])
    approved = action == "approve"
    q("UPDATE orders SET status=? WHERE id=?", ("approved" if approved else "declined", oid)); db.commit()
    cap = (qy.message.caption or "") + ("\n\n✅ APPROVED — chat with the buyer by replying to their messages here" if approved else "\n\n❌ DECLINED")
    try:
        await qy.message.edit_caption(cap, reply_markup=Kb([[Btn("✅ Approved" if approved else "❌ Declined", callback_data="noop")]]))
    except Exception:
        pass
    if approved:
        add_chat(uid, "admin", f"Hi! 👋 Your payment for order #{oid} is approved. Send me the email/account to deliver to and I'll set it up right here.")
        try:
            await ctx.bot.send_message(int(uid), f"🎉 Payment approved! Order #{oid} is verified.\nLive chat with the admin is now open.", reply_markup=open_chat_kb())
        except Exception as e:
            await qy.message.reply_text(f"⚠️ Approved, but couldn't DM the user: {e}")
    else:
        try:
            await ctx.bot.send_message(int(uid), f"❌ Payment for order #{oid} could not be verified. Please contact support or resend a clear receipt.")
        except Exception:
            pass

# ---------- admin replies (swipe-reply to a forwarded message, or /reply <id> <text>) ----------
async def admin_text(update: Update, ctx):
    m = update.message
    if not m or update.effective_user.id != ADMIN_ID or not m.text:
        return
    uid = text = None
    if m.reply_to_message:
        r = q("SELECT uid FROM relay WHERE admin_msg_id=?", (m.reply_to_message.message_id,))
        if r: uid, text = r[0][0], m.text
    elif m.text.startswith("/reply "):
        p = m.text.split(" ", 2)
        if len(p) == 3: uid, text = p[1], p[2]
    if not uid:
        return await m.reply_text("Reply to a buyer's message (swipe) or use /reply <user_id> <text>.")
    add_chat(uid, "admin", text)
    if time.time() - last_seen.get(uid, 0) > 45:  # buyer isn't looking at the chat — nudge them
        try: await ctx.bot.send_message(int(uid), "💬 New message from Maven admin", reply_markup=open_chat_kb("Open chat"))
        except Exception: pass
    await m.reply_text("✓ sent")

# ---------- Mini App API ----------
def auth(request, init=None):
    init = init or request.headers.get("X-Init-Data", "")
    d = dict(parse_qsl(init)); h = d.pop("hash", "")
    chk = "\n".join(f"{k}={v}" for k, v in sorted(d.items()))
    key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    if not h or not hmac.compare_digest(hmac.new(key, chk.encode(), hashlib.sha256).hexdigest(), h) \
       or time.time() - int(d.get("auth_date", 0)) > 86400:
        raise web.HTTPUnauthorized(text="open from Telegram")
    return json.loads(d["user"])

@web.middleware
async def cors(request, handler):
    if request.method == "OPTIONS":
        resp = web.Response()
    else:
        try: resp = await handler(request)
        except web.HTTPException as e: resp = e
    resp.headers.update({"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "X-Init-Data, Content-Type"})
    return resp

def make_api(bot):
    async def order(request):
        f = await request.post(); u = auth(request, f.get("initData")); uid = str(u["id"])
        shot = f.get("photo")
        if not shot or not hasattr(shot, "file"): raise web.HTTPBadRequest(text="screenshot required")
        oid = "MVN-" + str(int(time.time() * 1000))[-6:]
        q("INSERT INTO orders VALUES (?,?,?,?,?,?)", (oid, uid, f["product"], f["price"], "pending", int(time.time()))); db.commit()
        cap = f"New order #{oid}\nProduct: {f['product']}\nPrice: {f['price']}\nBuyer: {f['contact']} (@{u.get('username','-')})\nID: {uid}"
        await bot.send_photo(ADMIN_ID, shot.file.read(), caption=cap, reply_markup=Kb([[
            Btn("✅ Approve", callback_data=f"approve_{uid}_{oid}"), Btn("❌ Decline", callback_data=f"decline_{uid}_{oid}")]]))
        return web.json_response({"id": oid})

    async def orders(request):
        uid = str(auth(request)["id"])
        rows = q("SELECT id, product, price, status, ts FROM orders WHERE uid=? ORDER BY ts DESC", (uid,))
        return web.json_response([dict(zip(("id", "product", "price", "status", "ts"), r)) for r in rows])

    async def chat_get(request):
        uid = str(auth(request)["id"]); last_seen[uid] = time.time()
        ok = bool(q("SELECT 1 FROM orders WHERE uid=? AND status='approved'", (uid,)))
        after = int(request.query.get("after", 0))
        rows = q("SELECT id, sender, text, ts FROM chat WHERE uid=? AND id>? ORDER BY id", (uid, after)) if ok else []
        return web.json_response({"unlocked": ok, "messages": [dict(zip(("id", "sender", "text", "ts"), r)) for r in rows]})

    async def chat_post(request):
        u = auth(request); uid = str(u["id"])
        r = q("SELECT id FROM orders WHERE uid=? AND status='approved' ORDER BY ts DESC", (uid,))
        text = ((await request.json()).get("text") or "").strip()[:1000]
        if not r: raise web.HTTPForbidden(text="chat locked")
        if not text: raise web.HTTPBadRequest()
        add_chat(uid, "user", text)
        m = await bot.send_message(ADMIN_ID, f"💬 {u.get('first_name','')} (@{u.get('username','-')}) · #{r[0][0]}\n\n{text}\n\n↩️ Swipe-reply to answer")
        q("INSERT INTO relay VALUES (?,?)", (m.message_id, uid)); db.commit()
        return web.json_response({"ok": True})

    app = web.Application(middlewares=[cors], client_max_size=8 * 1024 * 1024)
    app.add_routes([web.post("/api/order", order), web.get("/api/orders", orders),
                    web.get("/api/chat", chat_get), web.post("/api/chat", chat_post),
                    web.get("/", lambda r: web.Response(text="Maven API ok"))])
    app.router.add_route("OPTIONS", "/{tail:.*}", lambda r: web.Response())
    return app

async def post_init(application):
    runner = web.AppRunner(make_api(application.bot)); await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", PORT).start()

def main():
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(ref_stats, pattern="^ref_stats$"))
    app.add_handler(CallbackQueryHandler(order_decision, pattern="^(approve|decline)_"))
    app.add_handler(MessageHandler(filters.TEXT, admin_text))
    print("Maven bot + API running"); app.run_polling()

if __name__ == "__main__":
    main()
