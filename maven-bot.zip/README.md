# Maven Store — two parts, deployed separately

web/  -> Vercel (static Mini App). In Vercel set Root Directory = `web`, or upload only this folder.
bot/  -> Render / Railway / VPS (Python). NOT for Vercel.

Bot env vars: BOT_TOKEN (new one from @BotFather), ADMIN_ID, WEBAPP_URL (your Vercel URL), BOT_USERNAME.
Start: pip install -r requirements.txt && python bot.py   (serves the API on $PORT, default 8080)
Then set `API` near the bottom of web/index.html to the bot's public HTTPS URL and redeploy web/.
